#include "vector.h"

Vector sample_unit_disk(void);